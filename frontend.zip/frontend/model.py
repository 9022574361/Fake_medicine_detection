from PIL import Image
import random

def predict_medicine(image_path):
    """
    Simulate medicine prediction.
    Replace this logic with your real trained ML model for production.
    """
    try:
        img = Image.open(image_path)
        width, height = img.size
        
        # Dummy logic: randomly predict Fake or Real
        result = random.choices(["Real Medicine", "Fake Medicine"], weights=[0.7, 0.3])[0]
        
        return result
    except FileNotFoundError:
        return "Image not found"
    except Exception as e:
        return f"Error: {str(e)}"